const db=require('../config/db');
const addDonner=(req,res)=>{
    const {
    first_name,
    last_name,
    blood_type,
    telephon,
    email,
    password,
    location,
    date_of_birth,
    available
} = req.body;
const query=`
INSERT INTO donors
(first_name, last_name, blood_type, telephon, email, password, location,date_of_birth, available)
VALUES(?,?,?,?,?,?,?,?,?)
`;
db.query(
    query,
    [first_name, last_name, blood_type, telephon, email, password, location, date_of_birth, available],
    (err, result) => {
        if(err){
            console.error(err);
            return res.status(500).json({ message: 'Error adding donner' });
        }
        res.status(201).json({ message: 'Donner added successfully', id: result.insertId });
    }
);
};
const updateDonner=(req,res)=>{
    const {id}=req.params;
    const{
    first_name,
    last_name,
    blood_type,
    telephon,
    location,
    available
}=req.body;
const query=`UPDATE donors SET first_name=?, last_name=? ,
blood_type=?, telephon=?, location=? , available=? WHERE id=?`;
db.query(
    query,[first_name,last_name,blood_type,telephon,location,available,id],
    (err,result)=>{
        if(err){
            console.error(err);
            return res.status(500).json({message:"Error updating donner"});
        }
        if (result.affectedRows===0){
            return res.status(404).json({message:"Donner not found"});
        }
        res.json({message:"Donner updated successfully"});
        }
    );
    };


module.exports={addDonner,updateDonner};
