const express = require("express");
const router = express.Router();

const { addDonner, updateDonner } = require("../controllers/donner.controller");

router.post("/add", addDonner);
router.put("/:id", updateDonner);

module.exports = router;