const mysql=require('mysql2');
const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'blood_donation_db'

});
db.connect((err)=>{
    if(err){
        console.error('Error connecting to mysql :',err);

    } else{
        console.log('connected to mysql database ');
    }
});
module.exports=db;